import { withCookies } from "react-cookie";

const Work = (): JSX.Element => {
  return <div></div>;
};

export default withCookies(Work);
