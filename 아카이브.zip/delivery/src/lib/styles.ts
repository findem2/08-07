export const center = "flex justify-center items-center";
export const mobilebox = "m-auto max-w-[30rem]";
export const box = "m-auto max-w-[80rem]";
