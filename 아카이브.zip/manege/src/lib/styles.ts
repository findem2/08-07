export const center: string = "flex justify-center items-center";
export const mobilebox: string = "m-auto max-w-[30rem]";
export const box: string = "m-auto max-w-[80rem]";
