import ManegeLayout from "./lib/Layout/manegelayout";

const App = (): JSX.Element => {
  return (
    <div>
      <ManegeLayout />
    </div>
  );
};

export default App;
